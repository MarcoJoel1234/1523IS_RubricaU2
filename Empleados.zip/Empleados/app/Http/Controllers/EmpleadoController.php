<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Empleado;

class EmpleadoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //Consultar un empleado
        return Empleado::all();
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //Instancear la clase Instrumento
        $empleado = new Empleado();
        //Asignar los valores de la petición al objeto
        $empleado->apellidoP = $request->input('apellidoP');
        $empleado->apellidoM = $request->input('apellidoM');
        $empleado->nombre = $request->input('nombre');
        $empleado->area = $request->input('area');
        $empleado->puesto = $request->input('puesto');
        $empleado->sueldo = $request->input('sueldo');
        //Guardar el objeto en la base de datos
        $empleado->save();
        //Mensaje de confirmación
        return 'Empleado agregado';
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        return Empleado::findOrFail($id)-get();
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $empleado = Empleado::findOrFail($id);
        $empleado->delete();
        //Mensaje de confirmación
        return  'Empleado eliminado';
    }
}
