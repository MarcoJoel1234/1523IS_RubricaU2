<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Instrumento;

class InstrumentoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Instrumento::all();
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //Instancear la clase Instrumento
        $instrumento = new Instrumento();
        //Asignar los valores de la petición al objeto
        $instrumento->nombre = $request->input('nombre');
        $instrumento->cantidad = $request->input('cantidad');
        $instrumento->marca = $request->input('marca');
        $instrumento->precio = $request->input('precio');
        //Guardar el objeto en la base de datos
        $instrumento->save();
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        return Instrumento::findOrFail($id);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $instrumento = Instrumento::findOrFail($id);
        $instrumento->delete();
    }
}
