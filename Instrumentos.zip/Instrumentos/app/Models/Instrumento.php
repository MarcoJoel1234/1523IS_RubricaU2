<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Instrumento extends Model
{
    protected $table = 'instrumento';
    protected $fillable = ['nombre', 'cantidad', 'marca', 'precio'];
    use HasFactory;
}
